package edu.gsu.cis.GroupProject;

import javax.swing.JOptionPane;

public class Customer extends User {
	public void manageMainMenu() {
		// Loop forever until the user select to end the application
		try {
			// Create the Airline Reservation application object
			AirlineReservation app = new AirlineReservation();
			
			int choice = 0;			
			choice = app.readMenuChoice("Select one of the following options:\n"
					+ "\t1: Book a Domestic Flight\n" 
					+ "\t2: Book an International Flight\n"
					+ "\t3: View Reservations\n"
					+ "\t4: Log Out\n", 4);

			switch (choice) {
				case 1:	app.bookDomesticFlight(); break;
				case 2: app.bookInternationalFlight(); break;
				case 3: app.manageReservations(); break;
				case 4: 
					// Display a farewell message
					JOptionPane.showMessageDialog(null, 
						"Thank you for using the airline reservation "
						+ "system. Have a nice day!", null, 
						JOptionPane.PLAIN_MESSAGE);
					System.exit(0);	// Terminate the application
				default:
					JOptionPane.showMessageDialog(null, "Unknown choice",
							"Error", JOptionPane.ERROR_MESSAGE);
			}			
		} catch (Exception ex) {
			// Display fatal error message
			JOptionPane.showMessageDialog(null, "Fatal Error", "Error", 
					JOptionPane.ERROR_MESSAGE);
			System.exit(1);
		}
	}
}