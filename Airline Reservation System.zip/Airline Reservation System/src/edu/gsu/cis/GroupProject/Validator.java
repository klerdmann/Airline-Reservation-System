package edu.gsu.cis.GroupProject;

public abstract class Validator {
	
		public abstract boolean isValidAddress(String street);
		
		public abstract boolean isValidState(String state);
	}

