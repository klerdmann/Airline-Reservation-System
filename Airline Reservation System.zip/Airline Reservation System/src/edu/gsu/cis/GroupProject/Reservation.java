package edu.gsu.cis.GroupProject;

public interface Reservation {
	public abstract void manageMainMenu();
}

