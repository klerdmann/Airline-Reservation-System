package edu.gsu.cis.GroupProject;

public interface Reservation {

	public void startApp();
	
	public int readMenuChoice(String message, int lastOption);

}
