package edu.gsu.cis.GroupProject;

import javax.swing.JOptionPane;

public class Admin extends User {
	public void manageMainMenu() {
		// Loop forever until the user select to end the application
		try {
			// Create the Airline Reservation application object
			AirlineReservation app = new AirlineReservation();
			
			int choice = 0;			
			choice = app.readMenuChoice("Select one of the following options:\n"
					+ "\t1: Book a Domestic Flight\n" 
					+ "\t2: Book an International Flight\n"
					+ "\t3: View Reservations\n" 
					+ "\t4: Add a Flight\n" 
					+ "\t5: Update a Flight\n"
					+ "\t6: Delete a Flight\n"
					+ "\t7: Log Out\n", 7);

			switch (choice) {
				case 1:	app.bookDomesticFlight(); break;
				case 2: app.bookInternationalFlight(); break;
				case 3: app.manageReservations(); break;
				case 4: app.addFlight(); break;
				case 5: app.updateFlight(); break;
				case 6: app.deleteFlight(); break;
				case 7: 
					// Display a farewell message
					JOptionPane.showMessageDialog(null, 
						"Thank you for using the airline reservation "
						+ "system. Have a nice day!", null, 
						JOptionPane.PLAIN_MESSAGE);
					System.exit(0);	// Terminate the application
				default:
					JOptionPane.showMessageDialog(null, "Unknown choice",
							"Error", JOptionPane.ERROR_MESSAGE);
			}
		} catch (Exception ex) {
			// Display fatal error message
			JOptionPane.showMessageDialog(null, "Fatal Error", "Error", 
					JOptionPane.ERROR_MESSAGE);
			System.exit(1);
		}
	}
}